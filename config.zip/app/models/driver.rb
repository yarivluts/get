class Driver < ApplicationRecord
end
