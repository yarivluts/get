class Metric < ApplicationRecord
end
